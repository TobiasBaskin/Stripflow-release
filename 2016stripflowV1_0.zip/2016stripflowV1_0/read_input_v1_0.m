clc, clear, close all;

frame1num = 1;
frame2num = 2;
stripwidth = 20;
CLEAN = 0;
%*************************** READ-IN INPUT FILE %************************
folder = '/Users/baskint/Documents/!aaahop work files/a_papers/Stripflow-Pub/testfolders/MultistackTest/';
fid = fopen([folder 'input.txt'], 'r');

% growth direction with 1 standing for left to right
dat_line = fgetl(fid);
growDirect = sscanf(dat_line,'%f');

% defaulting the order of segments = 1
dat_line = fgetl(fid);
baseframe = sscanf(dat_line,'%f');

% number of stacks
dat_line = fgetl(fid);
nstack = sscanf(dat_line,'%f');

% calibration
dat_line = fgetl(fid);
pixpermicron = sscanf(dat_line,'%f');

dat_line = fgetl(fid); % defaulting the mosaic method = 2

% amount of camera motion in microns
dat_line = fgetl(fid);
camshift = sscanf(dat_line,'%f');
% time of center frame for each stack
for sn = 1:nstack,
    dat_line = fgetl(fid);
    tmp = sscanf(dat_line,'%f',[1,3]);
    timestamp(sn) = tmp(1)*60*60 + tmp(2)*60 + tmp(3);
end
% defines stacks for geometry input
midline = zeros(nstack, 20); % pair-wise points (x,y) defining midline
dlr = zeros(nstack,2); % root diameter in pixels
for sn = 1:nstack,
    
    dat_line = fgetl(fid);
    dat_line = fgetl(fid);
    tmp = sscanf(dat_line,'%f %f,',[1,inf]); tmp(tmp==0) = 1;
    midline(sn,1:length(tmp)) = tmp;
    dat_line = fgetl(fid);
    dlr(sn,:) = sscanf(dat_line,'%*s %f %f')';
end
dat_line = fgetl(fid);
% time interval between consecutive frames in seconds
dat_line = fgetl(fid);
tspace = sscanf(dat_line,'%f')';
% coordinates of the quiescent center
dat_line = fgetl(fid);
qc = sscanf(dat_line,'%f %f')';
% final numerical output file
outputfile = fgetl(fid);
fclose(fid);


% ****************************** COMPUTATIONS *****************************
imfolder = [folder 'tiff/'];
[name, errmsg] = sprintf('stack%04dframe%04d.tif', 1, frame1num);

midline2 = midline;
if growDirect == 0,
%    im1 = imread([imfolder 'stack0001frame000' num2str(frame1num)],'tiff');
    im1 = imread([imfolder name],'tiff');
    [Ih, Iw] = size(im1);
    for sn = 1:nstack,
        tmp = sum(midline(sn,:)>0);
        midline(sn,1:2:tmp) = Iw - midline(sn,tmp-1:-2:1) + 1;
        midline(sn,2:2:tmp) = midline(sn,tmp:-2:1) + 1;
    end
    dlr = dlr(:,end:-1:1);
    qc(1) = Iw - qc(1) + 1;
end

for sn = 1:nstack,
    SN = baseframe*(2*sn-nstack-1) + (nstack-sn+1);
    [name1, errmsg] = sprintf('stack%04dframe%04d.tif', SN, frame1num);
%    im1 = imread([imfolder 'stack000' num2str(SN) 'frame000' num2str(frame1num)],'tiff');
    im1 = imread([imfolder name1],'tiff');
    im1 = double(im1);
    [name2, errmsg] = sprintf('stack%04dframe%04d.tif', SN, frame2num);
%    im2 = imread([imfolder 'stack000' num2str(SN) 'frame000' num2str(frame2num)],'tiff');
    im2 = imread([imfolder name2],'tiff');
    im2 = double(im2);

    if growDirect == 0, % flip images
        im1 = im1(:,end:-1:1);
        im2 = im2(:,end:-1:1);
    end

    [Ih, Iw] = size(im1);

    tmp = sum(midline(SN,:)>0);
    cx = midline(SN,1:2:tmp);
    cy = Ih - midline(SN,2:2:tmp);
%     cy = midline(SN,2:2:tmp);

    figure(1), imshow(im1,[]), title(['stack ' num2str(SN)]);
    figure(1), hold on, plot(cx,cy,'ro','LineWidth',2,...
        'MarkerEdgeColor','k', 'MarkerFaceColor','r', 'MarkerSize',8);
    if sn == 1,
        plot(qc(1),Ih - qc(2), 'go');
    end
    p = polyfit(cx,cy,min(3,length(cx)-1));
    midx = [min(cx):max(cx)]; midy = polyval(p,midx);
    plot(midx,midy,'--r','Linewidth',2), hold off;
    
    % save figure 1 - midline
    saveas(1, [folder outputfile(1:end-4) '-midline-' num2str(SN)], 'png');
    
    [motion, midx,midy] = stripflow_estimator(im1, im2, stripwidth,cx, cy, dlr(SN,1), dlr(SN,2));
    
    figure(3),plot(midx,motion)
    
    figure(2),imshow(im1,[]), hold on, plot(midx, midy);
    
    allMotion{sn} = motion;
    allMidx{sn} = midx;
    allMidy{sn} = midy;
end

% % % %****************************** MOSAICING *****************************
% save([folder 'intermediate.mat'],'allMotion','allMidx','allMidy')
% load ([folder 'intermediate.mat']); Iw = 1600;

% now invert the velocity and coords profiles
for sn = 1:nstack,
    if sn ~= nstack,
        midx = [max(allMidx{sn}):-1:min(allMidx{sn})];
    else
        midx = [min(max(allMidx{sn}),qc(1)): -1: min(allMidx{sn})];
    end
    allMidy{sn} = interp1(allMidx{sn},allMidy{sn},midx,'pchip');
    allMotion{sn} = interp1(allMidx{sn},allMotion{sn},midx,'pchip');
    allMidx{sn} = Iw - midx;
end

wvalid = round(camshift*pixpermicron); % camera translation in pixels
% tip velocity in pixels per second
velQc = allMotion{nstack}(1)/tspace/(frame2num - frame1num);
for sn = 1: nstack-1, 
    allMidx{sn} = allMidx{sn} + (nstack-sn)*wvalid + ...
        velQc * (timestamp(sn+1) - timestamp(sn));
    
    allMidx{sn} = round(allMidx{sn});
end

figure,hold on,
for sn = 1:nstack,
    plot(allMidx{sn}, allMotion{sn},'k','LineWidth',2);
end
title('raw measurement'),hold off;

% clean the data by throwing outliers
if CLEAN == 1,
    for sn = 1:nstack,

        brob = robustfit(allMidx{sn},allMotion{sn});
        fittedMotion = brob(1)+brob(2)*allMidx{sn};

        index = find(abs(allMotion{sn}-fittedMotion)>1);
        allMotion{sn}(index) = fittedMotion(index);
    end

    figure,hold on,
    for sn = 1:nstack,
        plot(allMidx{sn}, allMotion{sn},'k','LineWidth',2);
    end
    title('after data cleaning');
end

% mosaicing begins
% first make the velocity of base-stack as zero by assuming it does't move
%index1 = find(allMidx{1} == allMidx{2}(end));
index1 = find(allMidx{1} == allMidx{1}(end));
if isempty(index1) error('no overlapping'); end
warning off, p = polyfit(allMidx{1},allMotion{1},3); warning on;
fittedMotion1 = polyval(p,allMidx{1});
allMotion{1} = allMotion{1} - mean(fittedMotion1(index1:end));

% then vertically shift following frame's velocity to match the previous 
% one succesively
for sn = 2:nstack,
    index1 = find(allMidx{sn} == allMidx{sn-1}(1));
    if isempty(index1) error('no overlapping'); end
    
    index2 = find(allMidx{sn-1} == allMidx{sn}(end));
    if isempty(index2) error('no overlapping'); end
    
    warning off, p = polyfit(allMidx{sn},allMotion{sn},3); warning on;
    fittedMotion1 = polyval(p,allMidx{sn});
    
    warning off, p = polyfit(allMidx{sn-1},allMotion{sn-1},3); warning on;
    fittedMotion2 = polyval(p,allMidx{sn-1});

    allMotion{sn} = allMotion{sn} + ...
        mean(fittedMotion2(1:index2)) - mean(fittedMotion1(index1:end));
end
figure,hold on,
for sn = 1:nstack,
    plot(allMidx{sn}, allMotion{sn},'k','LineWidth',2);
end
title('after vertical shift');

% average the measures
xcoord = [];
ycoord = [];
motion = [];
for sn = 1:nstack,
    xcoord = [xcoord allMidx{sn}];
    ycoord = [ycoord allMidy{sn}];
    motion = [motion allMotion{sn}];
end

xEst = [min(xcoord):max(xcoord)];
yEst = [];
vEst = [];
for i = xEst(1):xEst(end),
    index = find(xcoord == i);
    yEst  = [yEst mean(ycoord(index))];
    vEst = [vEst mean(motion(index))];
    
end
figure,hold on, plot(xEst,vEst,'k','LineWidth',2), title('after average');


pos = sqrt((xEst(1:end-1)-xEst(2:end)).^2 + (yEst(1:end-1)-yEst(2:end)).^2);
dEst = [0 cumsum(pos)];
figure,hold on, plot(dEst,vEst,'k','LineWidth',2), title('dist vs. vel');


%*********************** UNITS CONVERSION & OUTPUT %**********************
Est_Vel = vEst/pixpermicron/tspace/(frame2num - frame1num); % for two frames interval
Est_Dist = dEst/pixpermicron;
qcMax = Est_Vel(1);
Est_Vel = Est_Vel(1) - Est_Vel;

Est_Dist = Est_Dist';
Est_Vel = Est_Vel';

xpos = Est_Dist(end);
xpos = xpos / 10; 

ymax = max(Est_Vel);
yoffset = ymax / 10;
ypos_text_one = ymax - (yoffset);
ypos_text_two = ymax - (yoffset * 2);

figure,plot(Est_Dist,Est_Vel,'LineWidth',2),
xlabel('Distance from the quiescent center, um'),
ylabel('Velocity, um sec^-1'), title('ESTIMATED ROOT VELOCITY');

hold on;
text(xpos,ypos_text_one,['QC Velocity = ' num2str(qcMax)],'HorizontalAlignment','left');
text(xpos,ypos_text_two,['Strip Width = ' num2str(stripwidth)],'HorizontalAlignment','left');
hold off;

% save velocity profile as image
saveas(8, [folder outputfile(1:end-4) '-velo'], 'png');

% save results to putput txt file
fid = fopen([folder outputfile], 'wt');
output = [Est_Dist'; Est_Vel'];
fprintf(fid, '%10s %10s\n','Distance','Velocity');
fprintf(fid, '%10.8f %10.8f\n', output);
fclose(fid);
