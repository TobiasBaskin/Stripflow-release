clc, clear, close all;

frame1num = 1;
frame2num = 2;
stripwidth = 40;
CLEAN = 0;
%*************************** READ-IN INPUT FILE %************************
folder = '/Users/baskint/Documents/!aaahop work files/2014-15-Sabtick/Atransmitdlight/StripflowSingstack/14-4-inag-1/';
fid = fopen([folder 'input.txt'], 'r');

% growth direction with 1 standing for left to right
dat_line = fgetl(fid);
growDirect = sscanf(dat_line,'%f');

dat_line = fgetl(fid); % defaulting the order of segments = 1
baseframe = sscanf(dat_line,'%f');

% number of stacks
dat_line = fgetl(fid);
nstack = sscanf(dat_line,'%f');

% calibration

dat_line = fgetl(fid);
pixpermicron = sscanf(dat_line,'%f');

dat_line = fgetl(fid); % defaulting the mosaic method = 2

% amount of camera motion in microns
dat_line = fgetl(fid);
camshift = sscanf(dat_line,'%f');
% time of center frame for each stack

% defines stacks for geometry input
midline = zeros(nstack, 20); % pair-wise points (x,y) defining midline
dlr = zeros(nstack,2); % root diameter in pixels
for sn = 1:nstack,
    dat_line = fgetl(fid);
    dat_line = fgetl(fid);
    tmp = sscanf(dat_line,'%f %f,',[1,inf]); tmp(tmp==0) = 1;
    midline(sn,1:length(tmp)) = tmp;
    dat_line = fgetl(fid);
    dlr(sn,:) = sscanf(dat_line,'%*s %f %f')';
end
dat_line = fgetl(fid);
% time interval between consecutive frames in seconds
dat_line = fgetl(fid);
tspace = sscanf(dat_line,'%f')';
% coordinates of the quiescent center
dat_line = fgetl(fid);
qc = sscanf(dat_line,'%f %f')';
% final nmerical output file
outputfile = fgetl(fid);
imgFile1 = fgetl(fid);
imgFile2 = fgetl(fid);
fclose(fid);

% ****************************** COMPUTATIONS *****************************
imfolder = [folder 'tiff/'];
[name, errmsg] = sprintf('stack%04dframe%04d.tif', 1, frame1num);

midline2 = midline;
if growDirect == 0,
    im1 = imread([imfolder name],'tiff');
    [Ih, Iw] = size(im1);
    for sn = 1:nstack,
        tmp = sum(midline(sn,:)>0);
        midline(sn,1:2:tmp) = Iw - midline(sn,tmp-1:-2:1) + 1;
        midline(sn,2:2:tmp) = midline(sn,tmp:-2:1) + 1;
    end
    dlr = dlr(:,end:-1:1);
    qc(1) = Iw - qc(1) + 1;
end

for sn = 1:nstack,   
    if(~ischar(imgFile1) || ~ischar(imgFile2))
        SN = baseframe*(2*sn-nstack-1) + (nstack-sn+1);
        [imgFile1, errmsg] = sprintf('stack%04dframe%04d.tif', SN, frame1num);
        [imgFile2, errmsg] = sprintf('stack%04dframe%04d.tif', SN, frame2num);
    else
       SN = 1;
    end
    im1 = imread([imfolder imgFile1],'tiff'); im1 = double(im1);
    im2 = imread([imfolder imgFile2],'tiff'); im2 = double(im2);

    if growDirect == 0, % flip images
        im1 = im1(:,end:-1:1);
        im2 = im2(:,end:-1:1);
    end

    [Ih, Iw] = size(im1);

    tmp = sum(midline(SN,:)>0);
    cx = midline(SN,1:2:tmp);
    cy = Ih - midline(SN,2:2:tmp);

    figure(1), imshow(im1,[]), title(['stack ' num2str(SN)]);
    figure(1), hold on, plot(cx,cy,'ro','LineWidth',2,...
        'MarkerEdgeColor','k', 'MarkerFaceColor','r', 'MarkerSize',8);

    % create and use piecewise polynomial based on the center points
    midx = [min(cx):max(cx)]; 
    pp = interp1(cx,cy,'spline','pp');
    midy = ppval(pp, midx);
    plot(qc(1), Ih - qc(2), 'go');

    plot(midx,midy,'--r','Linewidth',1), hold off;

    %save image with the midline points and calculated midline
    saveas(1, [folder outputfile(1:end-4) '-midline'], 'png');
    
    [motion, midx,midy] = stripflow_estimator(im1, im2, stripwidth,cx, cy, dlr(SN,1), dlr(SN,2));
    
    allMotion{sn} = motion;
    allMidx{sn} = midx;
    allMidy{sn} = midy;
end

% % % %****************************** Extra Processing Steps *****************************

% now invert the velocity and coords profiles
for sn = 1:nstack,
    if sn ~= nstack,
        midx = [max(allMidx{sn}):-1:min(allMidx{sn})];
    else
        midx = [min(max(allMidx{sn}),qc(1)): -1: min(allMidx{sn})];
    end
    allMidy{sn} = interp1(allMidx{sn},allMidy{sn},midx,'pchip');
    allMotion{sn} = interp1(allMidx{sn},allMotion{sn},midx,'pchip');
    allMidx{sn} = Iw - midx;
end

wvalid = round(camshift*pixpermicron); % camera translation in pixels
% tip velocity in pixels per second
velQc = allMotion{nstack}(1)/tspace/(frame2num - frame1num); 
for sn = 1: nstack-1, 
    allMidx{sn} = allMidx{sn} + (nstack-sn)*wvalid + ...
        velQc * (timestamp(sn+1) - timestamp(sn));
    
    allMidx{sn} = round(allMidx{sn});
end

% clean the data by throwing outliers
if CLEAN == 1,
    for sn = 1:nstack,
        brob = robustfit(allMidx{sn},allMotion{sn});
        fittedMotion = brob(1)+brob(2)*allMidx{sn};

        index = find(abs(allMotion{sn}-fittedMotion)>1);
        allMotion{sn}(index) = fittedMotion(index);
    end
end

% average the measures
xcoord = [];
ycoord = [];
motion = [];
for sn = 1:nstack,
    xcoord = [xcoord allMidx{sn}];
    ycoord = [ycoord allMidy{sn}];
    motion = [motion allMotion{sn}];
end

xEst = [min(xcoord):max(xcoord)];
yEst = [];
vEst = [];
for i = xEst(1):xEst(end),
    index = find(xcoord == i);
    yEst  = [yEst mean(ycoord(index))];
    vEst = [vEst mean(motion(index))];
    
end

pos = sqrt((xEst(1:end-1)-xEst(2:end)).^2 + (yEst(1:end-1)-yEst(2:end)).^2);
dEst = [0 cumsum(pos)];

%*********************** UNITS CONVERSION & OUTPUT %**********************
Est_Vel = vEst/pixpermicron/tspace/(frame2num - frame1num); % for two frames interval
Est_Dist = dEst/pixpermicron;
qcMax = Est_Vel(1);
Est_Vel = Est_Vel(1) - Est_Vel;

Est_Dist = Est_Dist';
Est_Vel = Est_Vel';

xpos = Est_Dist(end);
xpos = xpos / 10; 

ymax = max(Est_Vel);
yoffset = ymax / 10;
ypos_text_one = ymax - (yoffset);
ypos_text_two = ymax - (yoffset * 2);

figure(2), plot(Est_Dist,Est_Vel,'LineWidth',2),
xlabel('Distance from the quiescent center, um'),
ylabel('Velocity, um sec^-1'), title('ESTIMATED ROOT VELOCITY');

hold on;
text(xpos,ypos_text_one,['QC Velocity = ' num2str(qcMax)],'HorizontalAlignment','left');
text(xpos,ypos_text_two,['Strip Width = ' num2str(stripwidth)],'HorizontalAlignment','left');
hold off;

% save velocity profile as image
saveas(2, [folder outputfile(1:end-4) '-velo'], 'png');
    
% save results to putput txt file
fid = fopen([folder outputfile], 'wt');
output = [Est_Dist'; Est_Vel'];
fprintf(fid, '%10s %10s\n','Distance','Velocity');
fprintf(fid, '%10.8f %10.8f\n', output);
fclose(fid);
