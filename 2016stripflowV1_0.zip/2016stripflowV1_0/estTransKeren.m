function [T_est,err,c] = estTransLK(I1,I2)
% A robust spatial registration scheme with sub-pixel accuracy in respect
% to the relative spatial shift (no rotation) between the images.

% Notion: I1: original image
%         I2: translated image
%
%         T_est: estimated translation parameter
%         error: average residual error (in the sense of least squares)
%         c: matrix condition number (larger is better)

% Reference: D. Keren, S. Peleg, and R. Brada. "Image sequence enhancement 
% using subpixel displacements. In IEEE Conference on Computer Vision and 
% Pattern Recognition, pages 742-746, 1988. 
%
% Author: Gang Dong
%         University of Massachusetts, Amherst
%         gdong@nsm.umass.edu
%         April 12 2006


%% Gaussian derivatives
% sigma = 1;
% sze = fix(6*sigma); if ~mod(sze,2); sze = sze+1; end
% f = fspecial('gaussian', sze, sigma); % Generate Gaussian filter.
% [fx,fy] = gradient(f); % Gradient of Gausian.
% Gx1 = filter2(fx, I1); % Gradient of the image in x direction
% Gy1 = filter2(fy, I1); % ... and y
% Gx2 = filter2(fx, I2);
% Gy2 = filter2(fy, I2);
% Gx = (Gx1 + Gx2)/2;
% Gy = (Gy1 + Gy2)/2;
% Gt = filter2(f, Gt2 - Gt1);

filter = [0.03504 0.24878 0.43234 0.24878 0.03504];
dfilter = [0.10689 0.28461 0.0  -0.28461  -0.10689];
Gx1 = conv2(I1,dfilter,'valid'); Gx1 = conv2(Gx1,filter','valid');
Gy1 = conv2(I1,filter,'valid'); Gy1 = conv2(Gy1,dfilter','valid');
Gx2 = conv2(I2,dfilter,'valid'); Gx2 = conv2(Gx2,filter','valid');
Gy2 = conv2(I2,filter,'valid'); Gy2 = conv2(Gy2,dfilter','valid');
Gx = (Gx1 + Gx2)/2;
Gy = (Gy1 + Gy2)/2;
Gt = conv2(I2-I1,filter,'valid'); Gt = conv2(Gt,filter','valid'); 

A11 = sum(sum(Gx.*Gx));
A12 = sum(sum(Gx.*Gy));
A21 = A12;
A22 = sum(sum(Gy.*Gy));

A = [A11 A12; A21 A22];
b = [-sum(sum(Gx.*Gt)); -sum(sum(Gy.*Gt))];

eigenvalues = eig(A);
uv = A\b;
c = rcond(A); %Matrix reciprocal condition number estimate
T_est = [uv(1), uv(2)];
err = mean2(sqrt((Gx*T_est(1) + Gy*T_est(2) + Gt).^2));