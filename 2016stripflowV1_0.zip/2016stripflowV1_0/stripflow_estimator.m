function [motion, midx, midy] = stripflow_estimator(I1, I2, stripwidth, cx, cy, ldir, rdir)

% notations
%   - I1: first frame
%   - I2: second frame
%   - cx: x-coordinates of inputed point of the medial axis
%   - cy: y-corrdinates of inputed point of the medial axis
%   - ldir: the length of left diameter
%   - rdir: the length of right diameter

%   - motion: velocity component parallel to the medial axis
%   - midx: x coordinates of the motion vector
%   - midy: y coordinates of the motion vector

% illumination calibration
I1 = I1 + 0.5*mean2(I2) - 0.5*mean2(I1);
I2 = I2 + 0.5*mean2(I1) - 0.5*mean2(I2);

wWin = stripwidth; % half width of the local estimation window;
[Ih,Iw] = size(I1);


% obtain the midline of the points provided in the input file
mid1x = [max(wWin+40,min(cx)) : min(Iw-wWin-40,max(cx))];  % need fine-tune

%p = polyfit(cx,cy,min(3,length(cx)-1));
%mid1y = polyval(p,mid1x);

% create piecewise polynomial
pp = interp1(cx,cy,'spline','pp');
mid1y = ppval(pp, mid1x);
mid1x = round(mid1x); mid1y = round(mid1y);

% half height of the window
hWin = linspace(ldir,rdir,length(mid1x)); 
hWin = round(hWin/2);

%computer tangent vector of the midline at each position
% if length(cx) == 2,
%     fx = polyval([p(1)],mid1x);
% elseif length(cx) == 3,
%     fx = polyval([2*p(1) p(2)],mid1x);
% elseif length(cx) > 3,
%     fx = polyval([3*p(1) 2*p(2) p(3)],mid1x);
% else
%     errordlg('Must input more than one midline point.','Error'); 
% end

% compute tangent vector at each position using the piecewise polynomial
% extract details from piece-wise polynomial by breaking it apart
[breaks,coefs,l,k,d] = unmkpp(pp);
% make the polynomial that describes the derivative
pp2 = mkpp(breaks,repmat(k-1:-1:1,d*l,1).*coefs(:,1:k-1),d);

fx = ppval(pp2,mid1x);
fx = fx./sqrt(fx.^2+1);
xn = 1./sqrt(fx.^2+1);

% For each point, obtain the positions of the window around that point
topx = mid1x + hWin.*fx;
topy = mid1y - hWin.*xn;
botx = mid1x - hWin.*fx;
boty = mid1y + hWin.*xn;

% FFT shift estimation for root regions
winFFT = round(Iw/3);
x1 = max(min(cx),winFFT+1); y1 = round(ppval(pp,x1));
x4 = min(max(cx),Iw-winFFT); y4 = round(ppval(pp,x4));
x2 = round(x1+(x4-x1)/3); y2 = round(ppval(pp,x2));
x3 = round(x1+2*(x4-x1)/3); y3 = round(ppval(pp,x3));

rootrad = round((ldir+rdir)/4);
im1 = I1(y1-rootrad:y1+rootrad,x1-winFFT:x1+winFFT);
im2 = I2(y1-rootrad:y1+rootrad,x1-winFFT:x1+winFFT);
[shiftx1,shifty1] = shift_fft(im1,im2);
im1 = I1(y2-rootrad:y2+rootrad,x2-winFFT:x2+winFFT);
im2 = I2(y2-rootrad:y2+rootrad,x2-winFFT:x2+winFFT);
[shiftx2,shifty2] = shift_fft(im1,im2);
im1 = I1(y3-rootrad:y3+rootrad,x3-winFFT:x3+winFFT);
im2 = I2(y3-rootrad:y3+rootrad,x3-winFFT:x3+winFFT);
[shiftx3,shifty3] = shift_fft(im1,im2);
im1 = I1(y4-rootrad:y4+rootrad,x4-winFFT:x4+winFFT);
im2 = I2(y4-rootrad:y4+rootrad,x4-winFFT:x4+winFFT);
[shiftx4,shifty4] = shift_fft(im1,im2);
clear im1, clear im2;

px = polyfit([x1 x2 x3 x4],[shiftx1 shiftx2 shiftx3 shiftx4], 2);
py = polyfit([x1 x2 x3 x4],[shifty1 shifty2 shifty3 shifty4], 2);

motionx = round(polyval(px,mid1x)); % motion estimate
motiony = round(polyval(py,mid1x));

mid2x = mid1x + polyval(px,mid1x); mid2x = round(mid2x);
mid2y = mid1y + polyval(py,mid1x); mid2y = round(mid2y);
motion = zeros(1,length(mid1x));

% Real computation starts...........
hbar = waitbar(0,'Please wait...');
w = length(mid1x);
% jump = wWin/2;
jump = wWin;
for i = 1:jump:w,
    im1win = I1(mid1y(i)-hWin(i):mid1y(i)+hWin(i),...
        mid1x(i)-wWin:mid1x(i)+wWin);
    im2win = I2(mid2y(i)-hWin(i):mid2y(i)+hWin(i),...
        mid2x(i)-wWin:mid2x(i)+wWin);

    estI1 = im1win;
    Iter = 1;
    err = 1;
    T_est = [0,0];

    [X,Y] = meshgrid(1:2*wWin+1,1:2*hWin(i)+1);

    while (Iter<10) & (err>0.01),
        [T_tmp,err,c] = estTransKeren(estI1,im2win);
        T_est = T_est + T_tmp;
        estI1 = interp2(I1,mid1x(i)-wWin-1+X-T_est(1), ...
            mid1y(i)-hWin(i)-1+Y-T_est(2),'cubic',0);
        Iter = Iter + 1;
    end

    motionx(i) = motionx(i) + T_est(1);
    motiony(i) = motiony(i) + T_est(2);
    motion(i) = motionx(i)*xn(i) + motiony(i)*fx(i); 
    waitbar(i/w)
end

close(hbar)
motionx = motionx(1:jump:w);
motiony = motiony(1:jump:w);
motion = motion(1:jump:w);

midx = mid1x(1:jump:w);
midy = mid1y(1:jump:w);

