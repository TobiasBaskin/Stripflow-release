function [shiftx,shifty] = shift_fft(I1,I2)
% The codes are to test the capability of Fourier transform-based method 
% for estimating position corresponds to the relative spatial shift between
% the images.

[h,w] = size(I1);
% Tukey window is used to make the image circularly symmetric and to avoid
% the boundary effects.
win = window(@tukeywin,h,0.25)*window(@tukeywin,w,0.25)';
I1 = win.*I1;
I2 = win.*I2;

% fprintf(1,'\nComputing ffts...');
f1 = fft2(I1);
f2 = fft2(I2);

numerator = f2.*conj(f1);
denominator = abs(f2.*conj(f1));

% fprintf(1,'\nBack transforming...');
phase = ifft2(numerator./denominator);

phase(1,1) = 0; % modification

[shifty,shiftx] = find(phase == max(max(phase)));
if shiftx < w/2,
    shiftx = shiftx-1;
else
    shiftx = shiftx-w-1;
end

if shifty < h/2,
    shifty = shifty-1;
else
    shifty = shifty-1-h;
end

% fprintf(1,'\nDone.\n');